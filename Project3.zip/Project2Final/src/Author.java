
public class Author {
	
	
	private String lastName;
	private String firstName;
	private List<String> listOfPaperTitles;
	
	/**
	 * Constructs an Author Object
	 */
	public Author(String lastName, String firstName, List<String> listOfPapers)
	{
		
	}
	
	public String getFirstName() 
	{
		
	}
	
	public String getLastName()
	{
		
	}
	public List<String> getListOfPaperTitles()
	{
		
	}
	public void setFirstName(String firstName)
	{
		
	}
	public void setLastName(String lastName)
	{
		
	}
	public  void addToList(String title)
	{
		
	}
}

